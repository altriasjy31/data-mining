import numpy as np
import scipy as scp
from scipy import stats
import matplotlib.pyplot as plt

import os
import re

class Plot(object):
    def __init__(self):
        self.currentDir = os.path.basename(os.path.realpath("."))
        self.filePath = None
    
    #数据是单行文件
    def getFile(self, filePath):
        self.filePath = filePath

    #数据通过空格间隔开
    def file2numpy(self, resultDir):
        m = r"[\\/](?P<fileName>[\w\u4e00-\u9fa5]+)$"
        # f_start, f_end = re.search(m,self.filePath).span()
        # fileName = self.filePath[f_start:f_end]
        fileName = re.search(m,self.filePath).group("fileName")
        self.dataPath = os.path.join(resultDir,fileName)

        data = np.loadtxt(self.filePath,np.float32)
        np.save(
            open(self.dataPath,"wb"),
            data
        )
    
    #data必须是numpy类型
    def loadData(self, dataPath=None):
        if dataPath is not None:
            self.dataPath = dataPath
        self.data = np.load(open(self.dataPath,"rb"))

    #计算平均值
    def average(self,data=None):
        if data is not None:
            print(np.average(data))
        else:
            print(np.average(self.data))
    
    #计算中位数
    def median(self, data=None):
        if data is not None:
            print(np.median(data))
        else:
            print(np.median(self.data))
    
    #计算标准差
    def standard_deviation(self,data=None):
        if data is not None:
            print(np.std(data))
        else:
            print(np.std(self.data))
    
    #计算众数
    def mode(self):
        print(stats.mode(self.data).mode)

    #计算中列数
    def midrange(self):
        data_max = np.max(self.data)
        data_min = np.min(self.data)
        print(1/2*(data_max+data_min))
    
    #计算第一个四分位数，第三个四分位数
    def quantiles(self):
        print(stats.mstats.mquantiles(self.data,[0.25,0.75]))
    
    #五数概括
    def number5(self):
        qs_1_3 = stats.mstats.mquantiles(self.data,[0.25,0.75])
        print("min:{} q1:{} mid:{} q3:{} max:{}\n".format(
            np.min(self.data),qs_1_3[0],
            np.median(self.data),qs_1_3[1],np.max(self.data)
            )
        )
    
    def boxplot(self,data=None):
        if data is not None:
            D = data
        else:
            D = self.data
        fig1, ax1 = plt.subplots()
        ax1.set_title('Data Boxplot')
        ax1.boxplot(D)
        return fig1, ax1
        
    
    def quantilesPlot(self):
        fig1, ax1 = plt.subplots()
        ax1.set_title("Quantiles Plot")
        quantiles = stats.probplot(self.data,plot=ax1)
        
    
    def qqPlot(self):
        fig1, ax1 = plt.subplots()
        ax1.set_title("quantiles-quantiles plot")
        probs = np.linspace(0,1,100)
        q_data_0 = stats.mstats.mquantiles(self.data[0],probs)
        q_data_1 = stats.mstats.mquantiles(self.data[1],probs)
        ax1.scatter(q_data_0,q_data_1)
        ax1.plot(q_data_0,q_data_0,color="y",linestyle="--")
        ax1.set_xlabel("age")
        ax1.set_ylabel("%fat")
        return fig1, ax1
    
    def scatterPlot(self):
        fig1, ax1 = plt.subplots()
        ax1.set_title("scatter plot")
        ax1.scatter(self.data[0],self.data[1])
        # line = np.linspace(np.min(self.data[0]),np.max(self.data))
        ax1.plot(self.data[0],self.data[0],color="y",linestyle="--")
        ax1.set_xlabel("age")
        ax1.set_ylabel("%fat")
        return fig1, ax1
        

def using_it():
    P = Plot()
    filePath = "dataset\dataFile01"
    npDir = "feature"
    P.getFile(filePath)
    P.file2numpy(npDir)
    P.loadData()
    P.average()
    P.median()
    P.mode()
    P.midrange()
    P.quantiles()
    P.number5()
    P.boxplot()
    P.quantilesPlot()
    plt.show()

def using_it01():
    P = Plot()
    filePath = "dataset\dataFile02"
    npDir = "feature"
    P.getFile(filePath)
    P.file2numpy(npDir)
    P.loadData()
    
    P.average(P.data[0])
    P.median(P.data[0])
    P.standard_deviation(P.data[0])

    P.average(P.data[1])
    P.median(P.data[1])
    P.standard_deviation(P.data[1])

    P.boxplot(P.data[0])
    P.boxplot(P.data[1])

    P.qqPlot()
    P.scatterPlot()
    plt.show()

    plt.show()

    
if __name__ == "__main__":
    using_it()
    using_it01()